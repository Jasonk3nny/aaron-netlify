# Photos
Here are the references to the photos used in the screendesign for you to download and edit according to the designs.
Please, also put the references as sources in the footer of your page.

* [https://commons.wikimedia.org/wiki/File:DANCE_-_Grupo_de_Rua,_%22Inoah,%22_at_Brooklyn_Academy_of_Music_(49020288773).jpg](https://commons.wikimedia.org/wiki/File:DANCE_-_Grupo_de_Rua,_%22Inoah,%22_at_Brooklyn_Academy_of_Music_(49020288773).jpg)
* [https://commons.wikimedia.org/wiki/File:Cheng_Tsung_Lung.jpg](https://commons.wikimedia.org/wiki/File:Cheng_Tsung_Lung.jpg)
* [https://commons.wikimedia.org/wiki/File:Meredith_Monk_-_On_Behalf_of_Nature_-_Brooklyn_Academy_of_Music_(15822608589).jpg](https://commons.wikimedia.org/wiki/File:Meredith_Monk_-_On_Behalf_of_Nature_-_Brooklyn_Academy_of_Music_(15822608589).jpg)
* [https://commons.wikimedia.org/wiki/File:DANCE_-_Grupo_de_Rua,_%22Inoah,%22_at_Brooklyn_Academy_of_Music_(49021032627).jpg](https://commons.wikimedia.org/wiki/File:DANCE_-_Grupo_de_Rua,_%22Inoah,%22_at_Brooklyn_Academy_of_Music_(49021032627).jpg)
* [https://commons.wikimedia.org/wiki/File:Meredith_Monk_-_On_Behalf_of_Nature_-_Brooklyn_Academy_of_Music_(15989693711).jpg](https://commons.wikimedia.org/wiki/File:Meredith_Monk_-_On_Behalf_of_Nature_-_Brooklyn_Academy_of_Music_(15989693711).jpg)

In your footer also mention:  
Yoga Icons by Vitaly Gorbachev from
* https://www.flaticon.com/free-icon/yoga_2043795
* https://www.flaticon.com/free-icon/yoga_2043787
* https://www.flaticon.com/free-icon/yoga_2043799
