#!/bin/sh
rm -rf ./dist
./build.sh
